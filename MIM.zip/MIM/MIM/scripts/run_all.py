"""Reproduce the full analysis pipeline and write results to outputs/.

Usage
-----
    python scripts/run_all.py

Writes a results text report, CSV tables, and PNG figures to ``outputs/``.
"""
from __future__ import annotations

import os
import sys
import json

# allow running from repo root without installing
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import mim
from mim import config, plots


def main() -> None:
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    outdir = os.path.join(root, config.OUTPUT_DIR)
    os.makedirs(outdir, exist_ok=True)

    df = mim.load_data()
    scores = mim.composite_scores(df)
    n = len(df)
    report = [f"MIM dual-pathway analysis  |  N = {n}", "=" * 60, ""]

    # 1. Reliability & validity
    rel = mim.reliability_table(df)
    rel.to_csv(os.path.join(outdir, "reliability.csv"), index=False)
    report += ["[1] RELIABILITY & CONVERGENT VALIDITY", rel.to_string(index=False), ""]

    # 2. Descriptives & correlations
    desc = mim.descriptives(scores)
    corr = mim.correlation_matrix(scores, df)
    desc.to_csv(os.path.join(outdir, "descriptives.csv"))
    corr.to_csv(os.path.join(outdir, "correlations.csv"))
    fl = mim.fornell_larcker_ok(scores, df)
    report += ["[2] DESCRIPTIVES", desc.to_string(),
               "", "CORRELATIONS (sqrt-AVE on diagonal)", corr.to_string(),
               f"Fornell-Larcker discriminant validity satisfied: {fl}", ""]

    # 3. Common method variance & multicollinearity
    harman = mim.harman_single_factor(df)
    vif = mim.full_collinearity_vif(scores)
    vif.to_csv(os.path.join(outdir, "vif.csv"), index=False)
    report += ["[3] COMMON METHOD VARIANCE & MULTICOLLINEARITY",
               f"Harman single-factor variance: {harman['first_factor_variance_pct']}% "
               f"(passes < 50%: {harman['passes']})",
               vif.to_string(index=False),
               f"Max VIF = {vif.attrs['max_vif']} (passes Kock < 3.3: {vif.attrs['passes_kock']})",
               ""]

    # 4. Parallel mediation
    med = mim.parallel_mediation(scores)
    med["indirect_effects"].to_csv(os.path.join(outdir, "mediation_indirect.csv"), index=False)
    report += ["[4] PARALLEL MEDIATION (standardized, PROCESS Model 4 logic)",
               "Path coefficients:",
               json.dumps(med["paths"], indent=2),
               "Indirect effects:",
               med["indirect_effects"].to_string(index=False),
               f"(bootstrap = {med['n_bootstrap']})", ""]

    # 5. Moderated mediation
    modmed = mim.moderated_mediation(scores)
    modmed["interactions"].to_csv(os.path.join(outdir, "moderated_interactions.csv"), index=False)
    modmed["conditional_indirect"].to_csv(
        os.path.join(outdir, "moderated_conditional.csv"), index=False)
    report += ["[5] MODERATED MEDIATION (moderator on b-paths, Model 14 logic)",
               "Interaction terms & index of moderated mediation:",
               modmed["interactions"].to_string(index=False),
               "", "Conditional indirect effects:",
               modmed["conditional_indirect"].to_string(index=False), ""]

    # 6. Power
    power = mim.sensitivity_power(n=n, k=6)
    report += ["[6] SENSITIVITY POWER ANALYSIS",
               json.dumps(power, indent=2), ""]

    # 7. Figures (derived from fitted results)
    plots.plot_descriptives(desc, rel, outdir)
    b1 = med["paths"][f"b1 ({config.MEDIATORS[0]}->{config.OUTCOME})"]
    b2 = med["paths"][f"b2 ({config.MEDIATORS[1]}->{config.OUTCOME})"]
    int1 = modmed["interactions"].iloc[0]["Coef"]
    int2 = modmed["interactions"].iloc[1]["Coef"]
    plots.plot_interaction(b1, int1, "Interactivity (std)",
                           "Interactivity x Communication Quality", outdir,
                           "fig_interaction_interactivity.png")
    plots.plot_interaction(b2, int2, "Task interruption (std)",
                           "Task Interruption x Communication Quality", outdir,
                           "fig_interaction_interruption.png")
    plots.plot_indirect_forest(med["indirect_effects"], outdir)
    report += ["[7] FIGURES written to outputs/ (fig_*.png)", ""]

    text = "\n".join(report)
    with open(os.path.join(outdir, "results_report.txt"), "w") as f:
        f.write(text)
    print(text)
    print(f"\nAll results written to: {outdir}")


if __name__ == "__main__":
    main()
