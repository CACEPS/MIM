# Changelog

All notable changes to this project are documented here.
This project follows semantic versioning.

## 1.1.0 (July 7, 2026)

### Changed
- Composite reliability (CR) and average variance extracted (AVE) are now
  computed from the standardized loadings of the joint five factor
  confirmatory measurement model. Earlier versions estimated these from the
  first principal component, which inflated CR and AVE. The confirmatory
  approach matches the measurement model reported in the manuscript, so the
  package now reproduces the manuscript convergent validity table exactly.
- `reliability.csv` gains a `Loading_range` column, reproducing the
  standardized loading ranges shown in the manuscript.
- The diagonal of `correlations.csv` (the Fornell and Larcker criterion) now
  uses the confirmatory AVE, so the discriminant validity values match the
  manuscript.

### Added
- Moderated mediation output now reports the regression inference for each
  interaction coefficient: standard error, t value, p value, and a 95 percent
  confidence interval. These values are deterministic and reproduce the
  interaction rows of the manuscript moderation table. The index of moderated
  mediation keeps its bias corrected bootstrap interval.
- `semopy` is now a dependency, used to fit the confirmatory factor model.

### Notes
- All point estimates are unchanged. Only CR and AVE change in value, moving
  from the principal component approximation to the confirmatory model. Every
  threshold still passes (CR above 0.70, AVE above 0.50, discriminant validity
  satisfied) and no substantive conclusion changes.
- Bootstrap intervals use a fixed seed (2025) and are reproducible across runs.

## 1.0.0

### Added
- Initial reproducible pipeline: reliability and convergent validity,
  descriptives and discriminant validity, common method variance (Harman and
  full collinearity VIF), parallel mediation with bootstrap indirect effects,
  moderated mediation, sensitivity power analysis.
