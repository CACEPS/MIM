"""Smoke tests: the pipeline loads data and produces well-formed results."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import mim


def test_load_and_shape():
    df = mim.load_data()
    assert len(df) == 235
    scores = mim.composite_scores(df)
    assert list(scores.columns) == mim.config.COMPOSITES


def test_reliability_range():
    df = mim.load_data()
    rel = mim.reliability_table(df)
    assert (rel["Cronbach_alpha"] > 0.5).all()
    assert (rel["AVE"] > 0.3).all()


def test_mediation_keys():
    df = mim.load_data()
    scores = mim.composite_scores(df)
    med = mim.parallel_mediation(scores, n_boot=200)
    assert "indirect_effects" in med
    assert len(med["indirect_effects"]) == 3


def test_vif_reasonable():
    df = mim.load_data()
    scores = mim.composite_scores(df)
    vif = mim.full_collinearity_vif(scores)
    assert vif["VIF"].max() < 10
