from setuptools import setup, find_packages

setup(
    name="mim",
    version="1.1.0",
    description="Dual-pathway JD-R analysis of mobile instant messaging and psychological workload",
    author="CACEPS",
    url="https://github.com/caceps/MIM",
    packages=find_packages(exclude=["tests", "scripts"]),
    python_requires=">=3.9",
    install_requires=[
        "numpy>=1.23", "pandas>=1.5", "scipy>=1.9", "matplotlib>=3.6", "semopy>=2.3",
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Intended Audience :: Science/Research",
    ],
)
