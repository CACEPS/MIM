"""Parallel mediation with bias-corrected bootstrap indirect effects.

Reproduces the logic of PROCESS Model 4: one predictor (X), two parallel
mediators (M1, M2), one outcome (Y). All variables are standardized so that
coefficients are interpretable as effect sizes.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from . import config


def _ols(y: np.ndarray, X: np.ndarray) -> np.ndarray:
    """Ordinary least squares coefficients (with intercept already in X)."""
    beta, *_ = np.linalg.lstsq(X, y, rcond=None)
    return beta


def _zscore(a: np.ndarray) -> np.ndarray:
    return (a - a.mean()) / a.std(ddof=1)


def _bias_corrected_ci(boot: np.ndarray, point: float, alpha: float):
    """Bias-corrected bootstrap percentile interval."""
    from scipy import stats
    boot = np.sort(boot)
    prop = np.mean(boot < point)
    prop = min(max(prop, 1e-6), 1 - 1e-6)
    z0 = stats.norm.ppf(prop)
    lo = stats.norm.cdf(2 * z0 + stats.norm.ppf(alpha / 2))
    hi = stats.norm.cdf(2 * z0 + stats.norm.ppf(1 - alpha / 2))
    return float(np.quantile(boot, lo)), float(np.quantile(boot, hi))


def parallel_mediation(
    scores: pd.DataFrame,
    x: str | None = None,
    mediators: list | None = None,
    y: str | None = None,
    n_boot: int = config.N_BOOTSTRAP,
    seed: int = config.RANDOM_SEED,
    alpha: float = config.ALPHA,
) -> dict:
    """Estimate a two-mediator parallel mediation model with bootstrapping."""
    x = x or config.PREDICTOR
    mediators = mediators or config.MEDIATORS
    y = y or config.OUTCOME
    m1, m2 = mediators

    d = scores[[x, m1, m2, y]].astype(float).apply(_zscore).values
    xi, m1i, m2i, yi = 0, 1, 2, 3
    n = d.shape[0]
    ones = np.ones(n)

    def fit(data):
        # a-paths: X -> M1, X -> M2
        Xa = np.column_stack([ones, data[:, xi]])
        a1 = _ols(data[:, m1i], Xa)[1]
        a2 = _ols(data[:, m2i], Xa)[1]
        # b-paths and direct: Y ~ M1 + M2 + X
        Xb = np.column_stack([ones, data[:, m1i], data[:, m2i], data[:, xi]])
        bcoef = _ols(data[:, yi], Xb)
        b1, b2, cp = bcoef[1], bcoef[2], bcoef[3]
        return a1, a2, b1, b2, cp

    a1, a2, b1, b2, cp = fit(d)
    ind1, ind2 = a1 * b1, a2 * b2
    total_ind = ind1 + ind2
    total_effect = cp + total_ind

    rng = np.random.default_rng(seed)
    boot = np.empty((n_boot, 3))
    for i in range(n_boot):
        idx = rng.integers(0, n, n)
        ba1, ba2, bb1, bb2, _ = fit(d[idx])
        boot[i] = [ba1 * bb1, ba2 * bb2, ba1 * bb1 + ba2 * bb2]

    ci1 = _bias_corrected_ci(boot[:, 0], ind1, alpha)
    ci2 = _bias_corrected_ci(boot[:, 1], ind2, alpha)
    cit = _bias_corrected_ci(boot[:, 2], total_ind, alpha)

    return {
        "paths": {
            f"a1 ({x}->{m1})": round(a1, 3),
            f"a2 ({x}->{m2})": round(a2, 3),
            f"b1 ({m1}->{y})": round(b1, 3),
            f"b2 ({m2}->{y})": round(b2, 3),
            f"c' (direct {x}->{y})": round(cp, 3),
            "total_effect": round(total_effect, 3),
        },
        "indirect_effects": pd.DataFrame([
            {"Effect": f"via {m1} (a1b1)", "Estimate": round(ind1, 3),
             "CI_low": round(ci1[0], 3), "CI_high": round(ci1[1], 3),
             "Significant": not (ci1[0] <= 0 <= ci1[1])},
            {"Effect": f"via {m2} (a2b2)", "Estimate": round(ind2, 3),
             "CI_low": round(ci2[0], 3), "CI_high": round(ci2[1], 3),
             "Significant": not (ci2[0] <= 0 <= ci2[1])},
            {"Effect": "total indirect", "Estimate": round(total_ind, 3),
             "CI_low": round(cit[0], 3), "CI_high": round(cit[1], 3),
             "Significant": not (cit[0] <= 0 <= cit[1])},
        ]),
        "n_bootstrap": n_boot,
    }
