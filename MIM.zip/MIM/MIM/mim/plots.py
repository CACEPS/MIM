"""Figure generation for the dual-pathway model.

All figures are derived from the fitted results, not from hard-coded numbers.
"""
from __future__ import annotations

import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

NAVY, GREEN, RED, GRAY = "#1F3864", "#3A7D44", "#B33A3A", "#595959"


def _save(fig, outdir, name):
    os.makedirs(outdir, exist_ok=True)
    path = os.path.join(outdir, name)
    fig.savefig(path, dpi=200, bbox_inches="tight")
    plt.close(fig)
    return path


def plot_descriptives(desc, reliability, outdir):
    """Bar chart of construct means with SD error bars and alpha labels."""
    names = list(desc.index)
    means = desc["mean"].values
    sds = desc["std"].values
    alphas = dict(zip(reliability["Construct"], reliability["Cronbach_alpha"]))
    fig, ax = plt.subplots(figsize=(8, 5))
    x = np.arange(len(names))
    ax.bar(x, means, yerr=sds, capsize=6, color="#2E5C8A", edgecolor=NAVY, alpha=0.85)
    ax.set_xticks(x)
    ax.set_xticklabels([n.replace("_", "\n") for n in names], fontsize=8)
    ax.set_ylabel("Mean (7-point scale, error bars = SD)")
    ax.set_title("Descriptive Statistics and Reliability", color=NAVY)
    for i, n in enumerate(names):
        if n in alphas:
            ax.text(i, means[i] + sds[i] + 0.15, f"a={alphas[n]:.2f}",
                    ha="center", fontsize=8, color=GRAY)
    ax.set_ylim(0, 7)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    return _save(fig, outdir, "fig_descriptives.png")


def plot_interaction(b_path, interaction_coef, xlabel, title, outdir, fname):
    """Simple-slopes plot at +/-1 SD of the moderator."""
    xs = np.linspace(-2, 2, 50)
    slope_hi = b_path + interaction_coef * 1
    slope_lo = b_path + interaction_coef * -1
    fig, ax = plt.subplots(figsize=(6.5, 5))
    ax.plot(xs, slope_lo * xs, color=RED, lw=2.2,
            label=f"Low comm. quality (-1 SD), slope={slope_lo:.3f}")
    ax.plot(xs, slope_hi * xs, color=GREEN, lw=2.2,
            label=f"High comm. quality (+1 SD), slope={slope_hi:.3f}")
    ax.axhline(0, color="gray", lw=0.6)
    ax.axvline(0, color="gray", lw=0.6)
    ax.set_xlabel(xlabel)
    ax.set_ylabel("Predicted psychological workload (std)")
    ax.set_title(title, color=NAVY, fontsize=11)
    ax.legend(fontsize=8, frameon=False)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    return _save(fig, outdir, fname)


def plot_indirect_forest(indirect_df, outdir):
    """Forest plot of indirect effects with bootstrap CIs."""
    labels = indirect_df["Effect"].tolist()
    est = indirect_df["Estimate"].values
    lo = indirect_df["CI_low"].values
    hi = indirect_df["CI_high"].values
    fig, ax = plt.subplots(figsize=(7.5, 4))
    y = np.arange(len(labels))
    for i in range(len(labels)):
        ax.plot([lo[i], hi[i]], [i, i], color=NAVY, lw=2)
        ax.plot(est[i], i, "o", color=RED if est[i] < 0 else GREEN, ms=8, zorder=3)
    ax.axvline(0, color="gray", ls="--", lw=0.8)
    ax.set_yticks(y)
    ax.set_yticklabels(labels, fontsize=9)
    ax.invert_yaxis()
    ax.set_xlabel("Indirect effect (95% bootstrap CI)")
    ax.set_title("Indirect Effects on Psychological Workload", color=NAVY, fontsize=11)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    return _save(fig, outdir, "fig_indirect_effects.png")
