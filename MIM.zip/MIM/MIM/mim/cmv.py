"""Common method variance and multicollinearity diagnostics.

Includes Harman's single-factor test and the full-collinearity VIF approach
(Kock, 2015), in which all predictor VIFs below 3.3 indicate a model free of
common method bias.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from . import config


def harman_single_factor(df: pd.DataFrame) -> dict:
    """Variance explained by the first unrotated factor across all items.

    Values below 50% are conventionally taken as evidence against a dominant
    method factor (Podsakoff et al., 2003).
    """
    all_items = [it for items in config.ITEMS.values() for it in items]
    x = df[all_items].astype(float)
    x = (x - x.mean()) / x.std(ddof=1)
    corr = np.corrcoef(x.values, rowvar=False)
    eigvals = np.linalg.eigvalsh(corr)[::-1]
    first_factor_pct = 100 * eigvals[0] / eigvals.sum()
    return {
        "first_factor_variance_pct": round(float(first_factor_pct), 3),
        "threshold_pct": 50.0,
        "passes": bool(first_factor_pct < 50.0),
    }


def full_collinearity_vif(scores: pd.DataFrame, predictors=None) -> pd.DataFrame:
    """Variance inflation factors from the construct correlation matrix.

    VIF_i is the i-th diagonal element of the inverse correlation matrix of the
    predictors. All VIF < 3.3 indicates no common-method-bias or
    multicollinearity concern (Kock, 2015).
    """
    if predictors is None:
        predictors = [config.PREDICTOR] + config.MEDIATORS + [config.MODERATOR]
    R = scores[predictors].corr().values
    Rinv = np.linalg.inv(R)
    rows = []
    for i, p in enumerate(predictors):
        vif = float(Rinv[i, i])
        rows.append({
            "Predictor": p,
            "R_squared": round(1 - 1 / vif, 3),
            "VIF": round(vif, 3),
        })
    out = pd.DataFrame(rows)
    out.attrs["max_vif"] = round(out["VIF"].max(), 3)
    out.attrs["passes_kock"] = bool(out["VIF"].max() < 3.3)
    return out
