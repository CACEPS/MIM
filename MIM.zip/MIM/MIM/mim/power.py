"""Sensitivity and achieved power for the moderated-mediation interactions.

Given N, alpha, and the number of predictors in the outcome equation, computes
the minimum detectable interaction effect (Cohen's f-squared) at target power
levels, and the achieved power for observed interaction effects.
"""
from __future__ import annotations

from scipy import stats

from . import config


def _power_for_f2(f2: float, n: int, k: int, alpha: float, num_df: int = 1) -> float:
    df_error = n - k - 1
    lam = f2 * (df_error + num_df + 1)
    crit = stats.f.ppf(1 - alpha, num_df, df_error)
    return float(1 - stats.ncf.cdf(crit, num_df, df_error, lam))


def min_detectable_f2(target_power: float, n: int, k: int,
                      alpha: float = config.ALPHA, num_df: int = 1) -> float:
    lo, hi = 1e-6, 3.0
    for _ in range(200):
        mid = (lo + hi) / 2
        if _power_for_f2(mid, n, k, alpha, num_df) < target_power:
            lo = mid
        else:
            hi = mid
    return round((lo + hi) / 2, 4)


def sensitivity_power(n: int, k: int = 6, alpha: float = config.ALPHA) -> dict:
    """Minimum detectable f-squared for a single interaction term."""
    return {
        "N": n,
        "k_predictors": k,
        "alpha": alpha,
        "f2_min_power_0.80": min_detectable_f2(0.80, n, k, alpha),
        "f2_min_power_0.95": min_detectable_f2(0.95, n, k, alpha),
        "cohen_benchmarks": {"small": 0.02, "medium": 0.15, "large": 0.35},
    }


def achieved_power(f2: float, n: int, k: int = 6, alpha: float = config.ALPHA) -> float:
    """Achieved power for a single interaction of observed effect size f2."""
    return round(_power_for_f2(f2, n, k, alpha), 3)
