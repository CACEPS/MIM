"""Moderated mediation: moderator on the b-paths (PROCESS Model 14 logic).

The moderator (W) conditions the mediator -> outcome paths. We estimate the
interaction terms, the index of moderated mediation, and conditional indirect
effects at low / mean / high moderator values, with bootstrap inference.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from . import config
from .mediation import _ols, _zscore, _bias_corrected_ci


def moderated_mediation(
    scores: pd.DataFrame,
    x: str | None = None,
    mediators: list | None = None,
    w: str | None = None,
    y: str | None = None,
    n_boot: int = config.N_BOOTSTRAP,
    seed: int = config.RANDOM_SEED,
    alpha: float = config.ALPHA,
) -> dict:
    """Estimate moderated mediation with the moderator on both b-paths."""
    x = x or config.PREDICTOR
    mediators = mediators or config.MEDIATORS
    w = w or config.MODERATOR
    y = y or config.OUTCOME
    m1, m2 = mediators

    d = scores[[x, m1, m2, w, y]].astype(float).apply(_zscore).values
    xi, m1i, m2i, wi, yi = 0, 1, 2, 3, 4
    n = d.shape[0]
    ones = np.ones(n)

    def fit(data):
        # a-paths
        Xa = np.column_stack([ones, data[:, xi]])
        a1 = _ols(data[:, m1i], Xa)[1]
        a2 = _ols(data[:, m2i], Xa)[1]
        # outcome model: Y ~ M1 + M2 + W + M1*W + M2*W + X
        m1w = data[:, m1i] * data[:, wi]
        m2w = data[:, m2i] * data[:, wi]
        Xb = np.column_stack([
            ones, data[:, m1i], data[:, m2i], data[:, wi], m1w, m2w, data[:, xi]
        ])
        c = _ols(data[:, yi], Xb)
        # c = [int, b1, b2, w, b1w, b2w, cp]
        return a1, a2, c[1], c[2], c[4], c[5]

    a1, a2, b1, b2, b1w, b2w = fit(d)

    # Analytic OLS inference for the interaction coefficients (deterministic).
    # Regression coefficients get t-based inference; the moderated-mediation
    # indices below get bootstrap CIs. This mirrors standard Model 14 reporting.
    from scipy import stats
    _m1w = d[:, m1i] * d[:, wi]
    _m2w = d[:, m2i] * d[:, wi]
    Xb = np.column_stack([
        ones, d[:, m1i], d[:, m2i], d[:, wi], _m1w, _m2w, d[:, xi]
    ])
    cfull = _ols(d[:, yi], Xb)
    resid = d[:, yi] - Xb @ cfull
    p_params = Xb.shape[1]
    sigma2 = float(resid @ resid) / (n - p_params)
    cov = sigma2 * np.linalg.inv(Xb.T @ Xb)
    se_all = np.sqrt(np.diag(cov))
    tcrit = stats.t.ppf(1 - alpha / 2, n - p_params)

    def _coef_inf(j):
        b = cfull[j]
        se = se_all[j]
        t = b / se
        pv = 2 * stats.t.sf(abs(t), n - p_params)
        return se, t, pv, b - tcrit * se, b + tcrit * se

    se_b1w, t_b1w, p_b1w, lo_b1w, hi_b1w = _coef_inf(4)
    se_b2w, t_b2w, p_b2w, lo_b2w, hi_b2w = _coef_inf(5)

    # index of moderated mediation = a * (interaction coefficient)
    imm1 = a1 * b1w
    imm2 = a2 * b2w

    # conditional indirect effects at W = -1, 0, +1 SD (already standardized)
    levels = {"low(-1SD)": -1.0, "mean": 0.0, "high(+1SD)": 1.0}

    rng = np.random.default_rng(seed)
    boot_imm = np.empty((n_boot, 2))
    boot_cond = {lv: np.empty((n_boot, 2)) for lv in levels}
    for i in range(n_boot):
        idx = rng.integers(0, n, n)
        ba1, ba2, bb1, bb2, bb1w, bb2w = fit(d[idx])
        boot_imm[i] = [ba1 * bb1w, ba2 * bb2w]
        for lv, wv in levels.items():
            boot_cond[lv][i] = [ba1 * (bb1 + bb1w * wv), ba2 * (bb2 + bb2w * wv)]

    ci_imm1 = _bias_corrected_ci(boot_imm[:, 0], imm1, alpha)
    ci_imm2 = _bias_corrected_ci(boot_imm[:, 1], imm2, alpha)

    interactions = pd.DataFrame([
        {"Interaction": f"{m1} x {w} -> {y}", "Coef": round(b1w, 3),
         "SE": round(se_b1w, 3), "t": round(t_b1w, 3), "p": round(p_b1w, 3),
         "CI_low": round(lo_b1w, 3), "CI_high": round(hi_b1w, 3),
         "IMM": round(imm1, 3), "IMM_CI_low": round(ci_imm1[0], 3),
         "IMM_CI_high": round(ci_imm1[1], 3),
         "Significant": not (ci_imm1[0] <= 0 <= ci_imm1[1])},
        {"Interaction": f"{m2} x {w} -> {y}", "Coef": round(b2w, 3),
         "SE": round(se_b2w, 3), "t": round(t_b2w, 3), "p": round(p_b2w, 3),
         "CI_low": round(lo_b2w, 3), "CI_high": round(hi_b2w, 3),
         "IMM": round(imm2, 3), "IMM_CI_low": round(ci_imm2[0], 3),
         "IMM_CI_high": round(ci_imm2[1], 3),
         "Significant": not (ci_imm2[0] <= 0 <= ci_imm2[1])},
    ])

    cond_rows = []
    for lv, wv in levels.items():
        est1 = a1 * (b1 + b1w * wv)
        est2 = a2 * (b2 + b2w * wv)
        c1 = _bias_corrected_ci(boot_cond[lv][:, 0], est1, alpha)
        c2 = _bias_corrected_ci(boot_cond[lv][:, 1], est2, alpha)
        cond_rows.append({"Moderator_level": lv, "Mediator": m1,
                          "Conditional_indirect": round(est1, 3),
                          "CI_low": round(c1[0], 3), "CI_high": round(c1[1], 3)})
        cond_rows.append({"Moderator_level": lv, "Mediator": m2,
                          "Conditional_indirect": round(est2, 3),
                          "CI_low": round(c2[0], 3), "CI_high": round(c2[1], 3)})

    return {
        "interactions": interactions,
        "conditional_indirect": pd.DataFrame(cond_rows),
        "n_bootstrap": n_boot,
    }
