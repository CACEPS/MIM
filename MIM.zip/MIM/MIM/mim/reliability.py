"""Reliability and convergent validity: Cronbach's alpha, CR, and AVE.

Composite reliability (CR) and average variance extracted (AVE) are computed
from the standardized loadings of the joint five-factor confirmatory
measurement model (all constructs estimated together). This is the same
reflective CFA reported in the manuscript, so the package reproduces the
manuscript's convergent-validity table exactly.
"""
from __future__ import annotations

import warnings

import numpy as np
import pandas as pd

from . import config

# Cache of fitted standardized loadings, keyed on the item data, so the joint
# CFA is estimated only once per dataset within a run.
_LOADINGS_CACHE: dict = {}


def cronbach_alpha(items: pd.DataFrame) -> float:
    """Cronbach's alpha for a set of item columns."""
    items = items.astype(float)
    k = items.shape[1]
    item_var = items.var(axis=0, ddof=1).sum()
    total_var = items.sum(axis=1).var(ddof=1)
    return float(k / (k - 1) * (1 - item_var / total_var))


def _all_items() -> list[str]:
    return [it for items in config.ITEMS.values() for it in items]


def cfa_standardized_loadings(df: pd.DataFrame) -> dict[str, np.ndarray]:
    """Standardized loadings from the joint reflective CFA (all constructs).

    Returns a mapping ``{construct: array of standardized loadings}`` in item
    order. The full five-factor measurement model is fitted once and cached.
    """
    items = _all_items()
    x = df[items].astype(float)
    key = hash(np.ascontiguousarray(x.values).tobytes())
    if key in _LOADINGS_CACHE:
        return _LOADINGS_CACHE[key]

    from semopy import Model  # imported lazily so the dependency is optional

    spec = "\n".join(
        f"{c} =~ " + " + ".join(its) for c, its in config.ITEMS.items()
    )
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        model = Model(spec)
        model.fit(x)
        est = model.inspect(std_est=True)

    loadings: dict[str, np.ndarray] = {}
    for construct, its in config.ITEMS.items():
        lam = []
        for it in its:
            row = est[(est["lval"] == it) & (est["op"] == "~")
                      & (est["rval"] == construct)]
            lam.append(float(row["Est. Std"].values[0]))
        loadings[construct] = np.array(lam)

    _LOADINGS_CACHE[key] = loadings
    return loadings


def _cr_from_loadings(lam: np.ndarray) -> float:
    lam = np.asarray(lam, dtype=float)
    err = 1 - lam ** 2
    return float((lam.sum() ** 2) / (lam.sum() ** 2 + err.sum()))


def _ave_from_loadings(lam: np.ndarray) -> float:
    lam = np.asarray(lam, dtype=float)
    return float((lam ** 2).mean())


def composite_reliability(df: pd.DataFrame, construct: str) -> float:
    """Composite reliability (CR / omega) for one construct, from CFA loadings."""
    return _cr_from_loadings(cfa_standardized_loadings(df)[construct])


def average_variance_extracted(df: pd.DataFrame, construct: str) -> float:
    """Average variance extracted (AVE) for one construct, from CFA loadings."""
    return _ave_from_loadings(cfa_standardized_loadings(df)[construct])


def reliability_table(df: pd.DataFrame) -> pd.DataFrame:
    """Loading range, alpha, CR, and AVE for every construct in the model."""
    loadings = cfa_standardized_loadings(df)
    rows = []
    for construct, items in config.ITEMS.items():
        lam = loadings[construct]
        rows.append({
            "Construct": construct,
            "N_items": len(items),
            "Loading_range": f"{lam.min():.3f}-{lam.max():.3f}",
            "Cronbach_alpha": round(cronbach_alpha(df[items]), 3),
            "CR": round(_cr_from_loadings(lam), 3),
            "AVE": round(_ave_from_loadings(lam), 3),
        })
    return pd.DataFrame(rows)
