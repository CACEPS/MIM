"""Central configuration: item groupings, construct names, and constants.

Editing this file is the only change needed to re-point the pipeline at a
differently named dataset.
"""

# Path to the dataset (relative to repo root)
DATA_FILE = "data/MIM_Workload_Data.csv"

# Reflective measurement model: construct -> list of item columns
ITEMS = {
    "MIM_Use":                ["TX1", "TX2", "TX3", "TX4", "TX5", "TX6"],
    "Interactivity":          ["JH1", "JH2", "JH3", "JH4"],
    "Task_Interruption":      ["GR1", "GR2", "GR3"],
    "Communication_Quality":  ["ZL1", "ZL2", "ZL3", "ZL4"],
    "Psychological_Workload": ["FH1", "FH2", "FH3"],
}

# Pre-computed composite (mean) score columns, if present in the file.
COMPOSITES = [
    "MIM_Use",
    "Interactivity",
    "Task_Interruption",
    "Communication_Quality",
    "Psychological_Workload",
]

# Roles in the dual-pathway model
PREDICTOR = "MIM_Use"
MEDIATORS = ["Interactivity", "Task_Interruption"]
MODERATOR = "Communication_Quality"
OUTCOME = "Psychological_Workload"

# Demographic / descriptive columns
DEMOGRAPHICS = [
    "Gender", "Age", "Education", "Work_Experience_Years", "Industry",
    "Primary_MIM_Tool", "MIM_Tools_Count", "Years_MIM_Use", "MIM_Contacts",
]

# Analysis constants
LIKERT_MIN, LIKERT_MAX = 1, 7
N_BOOTSTRAP = 5000
RANDOM_SEED = 2025
ALPHA = 0.05

OUTPUT_DIR = "outputs"
