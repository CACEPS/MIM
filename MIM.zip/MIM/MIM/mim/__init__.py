"""mim: reproducible analysis package for the MIM / psychological workload study.

Dual-pathway Job Demands-Resources analysis of mobile instant messaging (MIM)
and psychological workload, with communication quality as a moderator.
"""
from . import config
from .data_loading import load_data, composite_scores
from .reliability import (
    cronbach_alpha, composite_reliability, average_variance_extracted,
    reliability_table,
)
from .descriptives import descriptives, correlation_matrix, fornell_larcker_ok
from .cmv import harman_single_factor, full_collinearity_vif
from .mediation import parallel_mediation
from .moderation import moderated_mediation
from .power import sensitivity_power, achieved_power

__version__ = "1.1.0"

__all__ = [
    "config", "load_data", "composite_scores",
    "cronbach_alpha", "composite_reliability", "average_variance_extracted",
    "reliability_table", "descriptives", "correlation_matrix",
    "fornell_larcker_ok", "harman_single_factor", "full_collinearity_vif",
    "parallel_mediation", "moderated_mediation",
    "sensitivity_power", "achieved_power",
]
