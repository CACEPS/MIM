"""Descriptive statistics and the construct correlation matrix."""
from __future__ import annotations

import numpy as np
import pandas as pd

from . import config
from .reliability import average_variance_extracted


def descriptives(scores: pd.DataFrame) -> pd.DataFrame:
    """Mean, SD, min, max for each construct composite."""
    d = scores.describe().T[["mean", "std", "min", "max"]]
    return d.round(3)


def correlation_matrix(scores: pd.DataFrame, df=None) -> pd.DataFrame:
    """Pearson correlations among constructs.

    If the item-level frame ``df`` is supplied, the diagonal is replaced with
    the square root of each construct's AVE (Fornell-Larcker criterion).
    """
    corr = scores.corr().round(3)
    if df is not None:
        for construct, items in config.ITEMS.items():
            if construct in corr.columns:
                corr.loc[construct, construct] = round(
                    np.sqrt(average_variance_extracted(df, construct)), 3
                )
    return corr


def fornell_larcker_ok(scores: pd.DataFrame, df) -> bool:
    """True if sqrt(AVE) exceeds all off-diagonal correlations for each construct."""
    corr = scores.corr()
    for construct, items in config.ITEMS.items():
        sqrt_ave = np.sqrt(average_variance_extracted(df, construct))
        others = corr[construct].drop(construct).abs().max()
        if sqrt_ave <= others:
            return False
    return True
