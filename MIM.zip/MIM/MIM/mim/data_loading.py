"""Load and validate the MIM survey dataset."""
from __future__ import annotations

import os
import pandas as pd

from . import config


def _repo_root() -> str:
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def load_data(path: str | None = None) -> pd.DataFrame:
    """Load the survey CSV.

    Uses ``keep_default_na=False`` so that categorical codes are never
    silently coerced to missing values. Item columns are cast to float.

    Parameters
    ----------
    path : str, optional
        Path to the CSV. Defaults to ``config.DATA_FILE`` under the repo root.
    """
    if path is None:
        path = os.path.join(_repo_root(), config.DATA_FILE)
    df = pd.read_csv(path, keep_default_na=False)

    # Cast all item columns to numeric floats
    all_items = [it for items in config.ITEMS.values() for it in items]
    for col in all_items:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    # Cast composite columns if they already exist in the file
    for col in config.COMPOSITES:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")

    _validate(df)
    return df


def _validate(df: pd.DataFrame) -> None:
    all_items = [it for items in config.ITEMS.values() for it in items]
    missing = [c for c in all_items if c not in df.columns]
    if missing:
        raise ValueError(f"Dataset is missing expected item columns: {missing}")
    n_bad = df[all_items].isna().sum().sum()
    if n_bad:
        raise ValueError(f"Found {n_bad} non-numeric / missing item responses.")
    out_of_range = (
        (df[all_items] < config.LIKERT_MIN) | (df[all_items] > config.LIKERT_MAX)
    ).sum().sum()
    if out_of_range:
        raise ValueError(
            f"{out_of_range} item responses fall outside the "
            f"{config.LIKERT_MIN}-{config.LIKERT_MAX} Likert range."
        )


def composite_scores(df: pd.DataFrame, recompute: bool = False) -> pd.DataFrame:
    """Return a frame of the five construct composite (mean) scores.

    If ``recompute`` is True, composites are recomputed from the items even
    when pre-computed columns already exist in the file.
    """
    out = pd.DataFrame(index=df.index)
    for construct, items in config.ITEMS.items():
        if (not recompute) and construct in df.columns:
            out[construct] = df[construct].astype(float)
        else:
            out[construct] = df[items].astype(float).mean(axis=1)
    return out
